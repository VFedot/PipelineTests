# Changelog - Nordic Cool 4 

All notable changes to this project will be documented in this file.


## 4.9.0 - 23-08-2021

### Added
- Search functionality to look up the pages from the library
- Favicons
- Helper classes for spacings
- Helper classes for: dividers, overflow, text 
- Drawers/Sliders
- Pagination

### Fixed
- Scroll for modals when they have longer content
- Text panel for vertical stepper
- Bug fixes for: alerts, forms, modals, steppers 



## 4.8.11 - 15-07-2021

### Added
- Update user dropdown in navigation example with copyright statement and links to third party licenses and terms of service (VASP)
- Update login screen examples with correct copyright text and Visma logo (VASP)

### Fixed
- Long labels for Steppers
- Validation tooltip missalignment
- Main navigation - text in the user dropdown to be vertically aligned
- Carets for all drodpdowns should be grey
- Main menu for the documentation pages changed
- Interface control icons missing 'no-repeat'



## 4.8.10 - 16-06-2021

### Fixed
- Some image path had a typo in it and caused errors
- Bug fix for Switchers on disabled state



## 4.8.8 - 15-06-2021

### Added
- Cards list
- Full width modals

### Fixed
- Modals - when window height is short the footer of the modal was overflowing the content
- SVGs clean up and optimisation
- date picker - footer fix
- other bug fixes



## 4.8.7 - 06-05-2021

### Added
- Login pages
- Helper classes for spinners



## 4.8.6 - 29-04-2021

### Added
- New helper class to show/hide element on light/dark mode

### Fixed
- Search field bug
- Error in Angular projects - $prefix-path



## 4.8.5 - 20-04-2021

### Fixed
- error page bug fix



## 4.8.4 - 20-04-2021

### Added
- Error pages

### Fixed
- Readonly state for textareas
- Remove "text-align: left" from table cells
- Button too wide on smaller screens



## 4.8.3 - 7-04-2021

### Fixed
- Extra-large modal is smaller than large in certain resolution #19 
- Modals doesn't work well with forms/grid system #18 
- Icons not working proprely on Chrome in some cases
- Interface controls missing from Icons section
- Fix for stepper (disabled state and multiple options as markup intead of a tag)
- Fix for active state on rows in tables



## 4.8.2 - 16-03-2021

### Fixed
- In some cases the switch for dark-light mode wasn't working correctly
- icons didn't load proprely
- top navigation fixes (shadows, alignments for drop downs, dividers)



## 4.8.1 - 12-03-2021

### Fixed
- In some cases the switch for dark-light mode wasn't working correctly
- "!default" missing from the prefix-path in nc.min.scss, nc.dark.mode.scss and nc.light-dark.mode.scss



## 4.8.0 - 11-03-2021

### Added
- Dark mode version of the NC4 web library
- Changed the default styling of the scroll bars

### Fixed
- Attach button 
- Typo fix on Switch page
- Tabs fix - misalignments on zoom 



## 4.7.2 - 10-12-2020

### Added
- Repository migration to GitHub.
- Accessibility improvements on documantation pages for: collapsible list, list group, tabs, wizzard, badges, buttons, button groups, button dropdowns, pills, forms, images and toasts.
- Adding inputs group style and documentation.
- Adding visual indicators/icons for input/form validation.

### Fixed
-



## 4.7.1 - 06-10-2020

### Added
-

### Fixed
- js folder missing from npm



## 4.7.0 - 06-10-2020

### Added
Datepicker

### Fixed
Bug fixes for popovers and accesibilty issues



## 4.6.2 - 16-09-2020

### Added
-

### Fixed
Bug fixes: Spinners fix and badges on list groups



## 4.6.1 - 14-09-2020

### Added
-

### Fixed
Bug fixes - NPM error on install



## 4.6.0 - 14-09-2020

### Added
Breadcrumbs, badges, small updates on main navigation, CDN available, library is public on NPM (@vismaux/nordic-cool)

### Fixed
Bug fixes



## 4.5.0 - 4-09-2020

### Added
Compressed steppers, replaced PF Beau Sans with Ubuntu.

### Fixed
Changed the way the vertical stepper is acting on smaller screens, other bug fixes.



## 4.4.0 - 7-08-2020

### Added
Search fields, vertical stepper.

### Fixed
Bug and fixes.



## 4.3.0 - 25-06-2020

### Added
Horizontal stepper, popovers, tooltips, progress indicators, more icons for the top navigation.

### Fixed
Bug and fixes.



## 4.2.1 - 03-06-2020

### Added
Added to first and third level of top navigation max-height and scroll for overflow dropdown.
Removed the restriction for '.tab-content' class to be sibling to tabs controls.


### Fixed
Fix style conflict between top navigation and tabs.



## 4.2.0 - 29-05-2020

### Added
White version for the top navigation, wizards, tabs.

### Fixed
Bug fixes.



## 4.1.1 - 14-05-2020

### Added
Added sass files in dist, 

### Fixed
Npm error fix, top menu typo fix, bug fixes.



## 4.1.0 - 08-05-2020

### Added
Top menu, vertical menu, modals, switch buttons and images.

### Fixed
Bug fixes.



## 4.0.0 - 31-03-2020

### Added
Typography, grids, icons, buttons, from elements, tables, list groups, alerts, toasts, helper classes.



