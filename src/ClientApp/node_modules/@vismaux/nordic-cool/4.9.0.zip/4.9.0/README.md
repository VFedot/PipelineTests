# Nordic Cool 4 
Nordic Cool 4 styles created by Visma.
For release notes and what's new in this version, go to [https://ux.visma.com/weblibrary/latest/index.php](https://ux.visma.com/weblibrary/latest/index.php).


## How to install

### Here are the options you have: 

#### Direct download
The preferred way is to use the packaged and minified version: `nc.min.css` (contains only the standard light mode version), `nc.dark.mode.min.css` (contains only dark mode version) or `nc.light-dark.mode.min.css` (contains the standard light mode and dark mode versions of the library in the same file).
We have fully migrate the repository to GitHub. If you want access to the source files (Sass (scss) format), the full package is available at [https://github.com/Nordic-Cool/nc4](https://github.com/Nordic-Cool/nc4) and also in the zip file that you can download from [https://ux.visma.com/weblibrary/latest/index.php](https://ux.visma.com/weblibrary/latest/index.php).

#### CDN 
Also the CSS is available through CDN: [https://nc4-visma.s3.eu-north-1.amazonaws.com/latest/dist/css/nc.min.css](https://nc4-visma.s3.eu-north-1.amazonaws.com/latest/dist/css/nc.min.css).

#### NPM
All releases of Nordic Cool 4 are available through NPM.

    npm install @vismaux/nordic-cool --s


### JS files to include
We provide only a few js files on request for some components that we have in the library and are the scripts that we use to exemplify the way certain components should work.

### Fonts
By default, fonts (Open Sans) are loaded from Google Fonts, but also locally as a fallback (`fonts` folder). 
In addition, in some cases Ubuntu font is used, which is Visma's corporate font. This font is loaded from Google Fonts, `font.visma.com` or from `fonts` folder.

### Other files
The graphics (`img` folder).

